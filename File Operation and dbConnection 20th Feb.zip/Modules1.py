import os
import shutil
import time

src = r'C:\Users\vkumar15\Desktop\Desktop - Raman'
files = os.listdir(src)
#print(files)

for a in files:
     if a.endswith('.xls'):
          #shutil.copy(src+'\\'+a,r'C:\Users\vkumar15\Desktop')
          shutil.move(src+'\\'+a,r'C:\Users\vkumar15\Desktop')
          #print(a)
          #print(src+'\\'+a)

print(len(files))
#os.remove(r'C:\Users\vkumar15\Desktop\2.tmp')
#print('2.tmp is removed')


#time
t = time.localtime()
print(t.tm_mon)
print(t.tm_mday)

o = open(r'C:\Users\vkumar15\Desktop\output_'+str(t.tm_mday)+str(t.tm_mon)+'.txt','w')
o.write('hi')
o.close()






      
