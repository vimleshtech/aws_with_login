import mysql.connector


c =mysql.connector.connect(host='localhost',user='root',password='root',database='hrms')

cur = c.cursor()

cur.execute('select * from emp')

o = cur.fetchall()
#print(o)


w = open(r'C:\Users\vkumar15\Desktop\output_.txt','w')


for r in o:
     w.write(str(r[0])+','+r[1]+'\n')
     #print(r[0],r[1])



w.close()



