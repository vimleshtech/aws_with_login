a =111
b =44

if a>b:
    
    print('a is grreater')

else:
    print('b is greater')
    



for x in range(1,10):
    print(x)
    
