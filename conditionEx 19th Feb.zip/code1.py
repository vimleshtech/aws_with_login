#  comment line : test code
'''
a = 11  # here a is variable and 11 is data / value
b =40
c =a+b  #logic and expression 

print(c) #show data or result

'''


a =111 # int
b = 'sjgssh sshfsfsfgs'
print(type(a))
print(type(b))


b = "sjgssh sshfsfsfgs"
print(type(b))
s ='aws.abcd.com'

size = 200

a =333.444
print(type(a))



a = True
print(type(a))

##list
l =[11,222,333,444,'server1','server2']
print(type(l))

print(l)
l[1] =900
print(l)

#tuple
t = (11,222,333,444,55,66)
print(type(t))

print(t)
#t[1] =900 #error
print(t)



#
a = {'m':'monday','a':'alpha','t':'tata',1:'one',2:200}

print(a['a'])

print(a[2])


s = {'iphone','iphone','dell'}
print(s)


















    




