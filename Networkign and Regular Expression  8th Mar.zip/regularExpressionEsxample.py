import re

s = input('enter string :')
print('you have entered :',s)

o = re.match('(.*) is (.*)',s)  #is should be match

if o:  #if is is match/present 
     print('is is matched')
     print(o.groups())
     print(o.group(1))
     print(o.group(2))
else:
     print('not match')

##validate emailid
email = input('enter email id :')

o = re.match('(.*)@gmail.com',email)   
if o:
     print('valid gmail account')
else:
     print('invalid gmail account')
     
#
a = 'skjgs sgsf hg232233444%$$#####sjkhsjhsg'
print(re.findall('[a-z]',a)) #get all letters 
print(re.findall('[a-z ]',a)) #get all letters including space

print(re.findall('\d',a)) #get all digits 


     






