import socket as s #here s is alias 
import random

obj = s.socket()         # Create a socket object
host = s.gethostname() # Get local machine name

obj.bind((host,1234)) #port : any 2 to 6 digit unique number


obj.listen(50)                 # Now wait for client connection.

while True: #check for connection
     
   c, addr = obj.accept()     # Establish connection with client.

   print ('Got connection from', addr , c)

   
   c.send(str(random.randint(1000,10000))[0:4].encode())
   
   c.close()                # Close the connection
   







   




