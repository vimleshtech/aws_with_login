a ='my name 0338t3v36535c$$ s s $$ is abcd ptyon is '

o = a.split(' ')
#print(o)
for w in o:
     print('m is match in word ', w, ' = ',w.count('m'))
     
